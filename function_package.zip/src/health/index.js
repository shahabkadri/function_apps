// Security headers
const SECURITY_HEADERS = {
    'Content-Type': 'application/json',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0'
};

module.exports = async function (context, req) {
    const startTime = Date.now();
    context.log('Health check request received');
    
    try {
        // Basic health checks
        const healthData = {
            status: 'healthy',
            timestamp: new Date().toISOString(),
            uptime: process.uptime(),
            version: '1.1.0',
            environment: process.env.NODE_ENV || 'production',
            memory: {
                used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
                total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024)
            },
            responseTime: Date.now() - startTime
        };
        
        // Check environment variables (without exposing values)
        const requiredEnvVars = ['AZURE_OPENAI_API_KEY'];
        const envCheck = {};
        
        for (const envVar of requiredEnvVars) {
            envCheck[envVar] = process.env[envVar] ? 'configured' : 'missing';
        }
        
        // Check if image API key is configured
        envCheck['IMAGE_API_KEY'] = 'configured'; // New o4-mini API key is hardcoded
        
        healthData.configuration = envCheck;
        
        // Model endpoints status
        healthData.models = {
            imageClassification: {
                endpoint: 'https://imageapi.openai.azure.com',
                deployment: 'o4-mini-deploy',
                status: 'configured'
            },
            textClassification: {
                endpoint: 'https://oss-120b-for-texts-resource.openai.azure.com',
                deployment: 'gpt-oss-120b-deploy', 
                status: envCheck['AZURE_OPENAI_API_KEY'] === 'configured' ? 'configured' : 'missing_key'
            }
        };
        
        // Simple dependency check
        try {
            // Test if we can make HTTP requests
            const testUrl = 'https://httpstat.us/200';
            const response = await fetch(testUrl, { 
                method: 'HEAD',
                timeout: 5000 
            });
            healthData.connectivity = response.ok ? 'ok' : 'degraded';
        } catch (connectError) {
            healthData.connectivity = 'error';
            context.log(`Connectivity check failed: ${connectError.message}`);
        }
        
        // Update response time
        healthData.responseTime = Date.now() - startTime;
        
        context.log(`Health check completed in ${healthData.responseTime}ms`);
        
        context.res = {
            status: 200,
            headers: SECURITY_HEADERS,
            body: healthData
        };
        
    } catch (error) {
        context.log(`Health check error: ${error.message}`);
        
        context.res = {
            status: 503,
            headers: SECURITY_HEADERS,
            body: {
                status: 'unhealthy',
                error: error.message,
                timestamp: new Date().toISOString(),
                responseTime: Date.now() - startTime
            }
        };
    }
};