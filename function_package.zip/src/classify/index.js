const axios = require('axios');
const Joi = require('joi');

// Security Configuration
const MAX_REQUEST_SIZE = 10 * 1024 * 1024; // 10MB limit
const REQUEST_TIMEOUT = 60000; // 60 seconds
const MAX_DESCRIPTION_LENGTH = 1000;
const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // 5MB for base64 image

// Azure OpenAI Configuration
const AZURE_OPENAI_API_KEY = process.env.AZURE_OPENAI_API_KEY;
const API_VERSION = "2025-01-01-preview";

// Model configurations with updated endpoints
const MODELS = {
    IMAGE: {
        deployment: "o4-mini-deploy",
        endpoint: "https://imageapi.openai.azure.com",
        apiKey: "veUss0tI2xlu1Spum72XNuH3Y7ZJekKfAvJiVuemYanKBZuBESRxJQQJ99BHACYeBjFXJ3w3AAABACOG3n5h",
        description: "o4-mini for image with text classification",
        maxTokens: 500
    },
    TEXT: {
        deployment: "gpt-oss-120b-deploy", 
        endpoint: "https://oss-120b-for-texts-resource.openai.azure.com",
        apiKey: AZURE_OPENAI_API_KEY, // Use environment variable for text model
        description: "gpt-oss-120b for text-only classification",
        maxTokens: 400
    }
};

// Request validation schema
const classifySchema = Joi.object({
    description: Joi.string().min(1).max(MAX_DESCRIPTION_LENGTH).required(),
    hasImage: Joi.boolean().default(false),
    imageData: Joi.when('hasImage', {
        is: true,
        then: Joi.string().base64().max(MAX_IMAGE_SIZE).required(),
        otherwise: Joi.forbidden()
    })
});

// Security headers
const SECURITY_HEADERS = {
    'Content-Type': 'application/json',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'Cache-Control': 'no-store, no-cache, must-revalidate'
};

// Rate limiting (basic implementation)
const requestCounts = new Map();
const RATE_LIMIT = 100; // requests per minute
const RATE_WINDOW = 60000; // 1 minute

function checkRateLimit(clientId) {
    const now = Date.now();
    const windowStart = now - RATE_WINDOW;
    
    if (!requestCounts.has(clientId)) {
        requestCounts.set(clientId, []);
    }
    
    const requests = requestCounts.get(clientId);
    const recentRequests = requests.filter(timestamp => timestamp > windowStart);
    
    if (recentRequests.length >= RATE_LIMIT) {
        return false;
    }
    
    recentRequests.push(now);
    requestCounts.set(clientId, recentRequests);
    
    // Cleanup old entries periodically
    if (Math.random() < 0.01) { // 1% chance to cleanup
        for (const [key, timestamps] of requestCounts.entries()) {
            const validTimestamps = timestamps.filter(t => t > windowStart);
            if (validTimestamps.length === 0) {
                requestCounts.delete(key);
            } else {
                requestCounts.set(key, validTimestamps);
            }
        }
    }
    
    return true;
}

function createErrorResponse(status, message, context) {
    context?.log(`Error: ${message}`);
    return {
        status,
        headers: SECURITY_HEADERS,
        body: JSON.stringify({ 
            error: message,
            timestamp: new Date().toISOString()
        })
    };
}

function sanitizeInput(input) {
    if (typeof input !== 'string') return input;
    return input.replace(/[<>'"&]/g, '');
}

module.exports = async function (context, req) {
    const startTime = Date.now();
    context.log('Waste classification request received');
    
    try {
        // Security check: API key validation for text model
        if (!AZURE_OPENAI_API_KEY) {
            context.log('Warning: Text model API key missing from environment');
        }
        
        // Rate limiting
        const clientId = req.headers['x-forwarded-for'] || 
                       req.headers['x-real-ip'] || 
                       'unknown';
        
        if (!checkRateLimit(clientId)) {
            return createErrorResponse(429, 'Rate limit exceeded. Please try again later.', context);
        }
        
        // Input validation
        const { error, value: validatedData } = classifySchema.validate(req.body, { 
            stripUnknown: true,
            abortEarly: false 
        });
        
        if (error) {
            const errorMessage = error.details.map(d => d.message).join(', ');
            return createErrorResponse(400, `Validation error: ${errorMessage}`, context);
        }
        
        // Sanitize inputs
        validatedData.description = sanitizeInput(validatedData.description);
        
        // Select model based on hasImage parameter
        const selectedModel = validatedData.hasImage ? MODELS.IMAGE : MODELS.TEXT;
        const modelUrl = `${selectedModel.endpoint}/openai/deployments/${selectedModel.deployment}/chat/completions?api-version=${API_VERSION}`;
        
        context.log(`Using ${validatedData.hasImage ? 'IMAGE' : 'TEXT'} model: ${selectedModel.description}`);
        context.log(`Endpoint: ${selectedModel.endpoint}`);
        
        // Prepare the request payload
        let messages;
        
        if (validatedData.hasImage && validatedData.imageData) {
            // Image + text classification using o4-mini
            messages = [
                {
                    role: "system",
                    content: `You are an expert waste classification AI trained on the Global Waste Classification Guide. Based on the image and/or description provided, classify the waste item into exactly one of these four categories:

1. **Recycle** - Items that can be processed into new materials (paper, cardboard, plastic bottles, metal cans, glass containers)
2. **Compost** - Organic materials that can decompose naturally (food scraps, yard waste, biodegradable materials)  
3. **Landfill** - Non-recyclable, non-compostable items that go to regular waste disposal (mixed materials, certain plastics, non-recyclable packaging)
4. **Hazardous** - Items requiring special disposal due to toxic/dangerous properties (batteries, electronics, chemicals, fluorescent bulbs)

Provide your response in JSON format with:
- "category": one of ["Recycle", "Compost", "Landfill", "Hazardous"]
- "confidence": confidence score from 0.0 to 1.0
- "reasoning": brief explanation of your classification decision
- "disposal_tips": specific instructions for proper disposal`
                },
                {
                    role: "user", 
                    content: [
                        {
                            type: "text",
                            text: `Classify this waste item: ${validatedData.description}`
                        },
                        {
                            type: "image_url",
                            image_url: {
                                url: `data:image/jpeg;base64,${validatedData.imageData}`
                            }
                        }
                    ]
                }
            ];
        } else {
            // Text-only classification using gpt-oss-120b
            messages = [
                {
                    role: "system",
                    content: `You are an expert waste classification AI trained on the Global Waste Classification Guide. Based on the description provided, classify the waste item into exactly one of these four categories:

1. **Recycle** - Items that can be processed into new materials (paper, cardboard, plastic bottles, metal cans, glass containers)
2. **Compost** - Organic materials that can decompose naturally (food scraps, yard waste, biodegradable materials)
3. **Landfill** - Non-recyclable, non-compostable items that go to regular waste disposal (mixed materials, certain plastics, non-recyclable packaging)  
4. **Hazardous** - Items requiring special disposal due to toxic/dangerous properties (batteries, electronics, chemicals, fluorescent bulbs)

Provide your response in JSON format with:
- "category": one of ["Recycle", "Compost", "Landfill", "Hazardous"]
- "confidence": confidence score from 0.0 to 1.0
- "reasoning": brief explanation of your classification decision
- "disposal_tips": specific instructions for proper disposal`
                },
                {
                    role: "user",
                    content: `Classify this waste item: ${validatedData.description}`
                }
            ];
        }
        
        // Make API call to Azure OpenAI
        const response = await axios.post(modelUrl, {
            messages: messages,
            max_tokens: selectedModel.maxTokens,
            temperature: 0.1,
            response_format: { type: "json_object" }
        }, {
            headers: {
                'Content-Type': 'application/json',
                'api-key': selectedModel.apiKey
            },
            timeout: REQUEST_TIMEOUT
        });
        
        const aiResponse = response.data;
        let classificationResult;
        
        try {
            classificationResult = JSON.parse(aiResponse.choices[0].message.content);
        } catch (parseError) {
            context.log(`JSON parse error: ${parseError.message}`);
            return createErrorResponse(500, 'Invalid AI response format', context);
        }
        
        // Validate AI response structure
        const requiredFields = ['category', 'confidence', 'reasoning', 'disposal_tips'];
        const validCategories = ['Recycle', 'Compost', 'Landfill', 'Hazardous'];
        
        for (const field of requiredFields) {
            if (!classificationResult.hasOwnProperty(field)) {
                context.log(`Missing required field in AI response: ${field}`);
                return createErrorResponse(500, 'Incomplete AI response', context);
            }
        }
        
        if (!validCategories.includes(classificationResult.category)) {
            context.log(`Invalid category in AI response: ${classificationResult.category}`);
            return createErrorResponse(500, 'Invalid category in AI response', context);
        }
        
        // Ensure confidence is a number between 0 and 1
        if (typeof classificationResult.confidence !== 'number' || 
            classificationResult.confidence < 0 || 
            classificationResult.confidence > 1) {
            classificationResult.confidence = 0.8; // Default confidence
        }
        
        const processingTime = Date.now() - startTime;
        
        // Prepare final response
        const finalResponse = {
            ...classificationResult,
            metadata: {
                processingTime: `${processingTime}ms`,
                modelUsed: selectedModel.description,
                endpointUsed: selectedModel.endpoint,
                hasImageData: validatedData.hasImage,
                version: '1.1.0',
                timestamp: new Date().toISOString()
            }
        };
        
        context.log(`Classification completed in ${processingTime}ms using ${selectedModel.description}`);
        context.log(`Result: ${classificationResult.category} (${Math.round(classificationResult.confidence * 100)}% confidence)`);
        
        context.res = {
            status: 200,
            headers: SECURITY_HEADERS,
            body: finalResponse
        };
        
    } catch (error) {
        context.log(`Classification error: ${error.message}`);
        context.log(`Stack trace: ${error.stack}`);
        
        if (error.response) {
            context.log(`API Error Response: ${JSON.stringify(error.response.data)}`);
            context.log(`API Error Status: ${error.response.status}`);
        }
        
        if (error.code === 'ECONNABORTED') {
            return createErrorResponse(408, 'Request timeout. Please try again.', context);
        }
        
        if (error.response && error.response.status === 401) {
            return createErrorResponse(500, 'API authentication failed', context);
        }
        
        if (error.response && error.response.status === 429) {
            return createErrorResponse(429, 'API rate limit exceeded. Please try again later.', context);
        }
        
        return createErrorResponse(500, 'Classification service temporarily unavailable', context);
    }
};